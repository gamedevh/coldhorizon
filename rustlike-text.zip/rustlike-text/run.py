from game.main_menu import main_menu

if __name__ == "__main__":
    main_menu()
